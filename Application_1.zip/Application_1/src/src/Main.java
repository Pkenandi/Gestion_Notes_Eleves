package src;

public class Main {
	
	public static void main(String [] args)
	{
		ClassRoom GR = new ClassRoom();
		
		GR.Saisir();
		
		GR.Afficher();
	}
	
	
}
